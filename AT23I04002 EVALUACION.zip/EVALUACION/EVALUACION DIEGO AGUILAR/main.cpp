#include <iostream>
#include "Cliente.h"
#include "Fecha.h"
#include "Pago.h"
#include "Prestamo.h"
#define Var 50
using namespace std;

int menu() {
    int op;
    cout << "MENU PRINCIPAL\n";
    cout << "AT23I04002 DIEGO JESUS AGUILAR TADEO" << endl;
    cout << "1. AGREGAR CLIENTES A LA LISTA\n";
    cout << "2. AGREGAR PRESTAMO A LA LISTA\n";
    cout << "3. HACER PAGO DEL PRESTAMO\n";
    cout << "4. MOSTRAR LISTA DE CLIENTE\n";
    cout << "5. MOSTRAR LISTA DE PRESTAMO\n";
    cout << "6. MOSTRAR DETALLES DEL PRESTAMO\n";
    cout << "7. SALIR DEL PROGRAMA\n";
    cout << "DIGITE LA OPCION: ";
    cin >> op;
    return op;
}

CLIENTE *agregarCliente() {
    CLIENTE *Cliente;
    int id;
    string nom,ape;
    cout<<"ESCRIBA EL CODIGO (ID) DEL CLIENTE"<<endl;
    cin>>id;
    cout<<"ESCRIBA EL NOMBRE DEL CLIENTE"<<endl;
    cin>>nom;
    cout<<"ESCRIBA APELLIDO DEL CLIENTE "<<endl;
    cin>>ape;
    Cliente= new CLIENTE(id,nom,ape);
    return Cliente;
}

CLIENTE *buscarCliente(CLIENTE *lstC[], int contC, int id) {
    bool encontrado=false;
    int contador=0;
    CLIENTE *cli=NULL;
    while(contador < contC && !encontrado) {
        if(lstC[contador]->getIdcliente()==id) {
            encontrado=true;
            cli=lstC[contador];
        } else {
            contador++;
        }
    }
    return cli;
}

Prestamo *agregarPrestamo(CLIENTE *lstcliente[], int cont) {
    int idclie,nump,d,m,a;
    Prestamo *pres=NULL;
    float monA;
    cout<<"DIGITE EL ID DEL CLIENTE"<<endl;
    cin>>idclie;
    CLIENTE *clik=buscarCliente(lstcliente,cont,idclie);
    if(clik) {
        cout<<"DIGITE EL NUMERO DEL PRESTAMO"<<endl;
        cin>>nump;
        cout<<"DIGITE EL MONTO APROBADO\n";
        cin>>monA;
        cout<<"ESCRIBA LA FECHA DEL PRESTAMO EN FORMATO DIA, MES Y ANO\n";
        cin>>d>>m>>a;
        fecha *feP=new fecha(d,m,a);
        pres= new Prestamo(nump);
        pres->setCliente(clik);
        pres->setMontoAprobado(monA);
        pres->setFecha(feP);
    }
    return pres;
}

Prestamo *buscarPrestamo(Prestamo *lstP[], int contP, int nup) {
    bool encontrado=false;
    int contador=0;
    Prestamo *pe=NULL;
    while(contador < contP && !encontrado) {
        if(lstP[contador]->getNumPrestamo()==nup) {
            encontrado=true;
            pe=lstP[contador];
        } else {
            contador++;
        }
    }
    return pe;
}

void mostrarCliente(CLIENTE *lst[], int cont) {
    if(cont == 0) {
        cout<<"LA LISTA DE CLIENTES ESTA LLENA\n";
    } else {
        cout<<"ID\tNOMBRE\tAPELLIDO\n";
        for(int i=0; i<cont; i++) {
            CLIENTE *cli=lst[i];
            cout<<cli->getIdcliente()<<"\t"<<cli->getNombre()<<"\t"<<cli->getApellido()<<"\n";
        }
    }
}

void mostrarPrestamo(Prestamo *lst[], int cont) {
    if(cont == 0) {
        cout<<"LA LISTA ESTA VACIA\n";
    } else {
        cout<<"ID\tCLIENTE\tMONTO\n";
        for(int i=0; i<cont; i++) {
            Prestamo *pre=lst[i];
            cout<<pre->getNumPrestamo()<<"\t"<<pre->getCliente()->getNombre()<<" "<<pre->getCliente()->getApellido()<<"\t"<<pre->getMontoAprobado()<<"\n";
        }
    }
}

void realizarPago(Prestamo *lst[], int cont) {
    if(cont == 0) {
        cout<<"LA LISTA DE PRESTAMOS ESTA VACIA\n";
    } else {
        int nump;
        cout<<"DIGITE EL NUMERO DE PRESTAMO: ";
        cin>>nump;
        Prestamo *prest=buscarPrestamo(lst,cont,nump);
        if(prest) {
            float montop;
            cout<<"DIGITE EL MONTO: ";
            cin>>montop;
            int dp,mp,ap;
            cout<<"DIGITE EL DIA DE PAGO: ";
            cin>>dp;
            cout<<"DIGITE EL MES DE PAGO: ";
            cin>>mp;
            cout<<"DIGITE EL ANO DE PAGO: ";
            cin>>ap;
            fecha *fp= new fecha(dp,mp,ap);
            Pago *pg=new Pago(fp,montop);
            prest->hacerPagos(pg);
            cout<<"EL PAGO SE REALIZO CON EXITO\n";
        } else {
            cout<<"NO SE ENCONTRO EL PRESTAMO\n";
        }
    }
}

void mostrarDetallesPrestamo(Prestamo *lst[], int cont) {
    if(cont == 0) {
        cout<<"LA LISTA DE PRESTAMOS ESTA VACIA\n";
    } else {
        int nump;
        cout<<"DIGITE EL NUMERO DE PRESTAMO: ";
        cin>>nump;
        Prestamo *prest=buscarPrestamo(lst,cont,nump);
        if(prest) {
            cout<<"MOSTRANDO LOS DETALLES DEL PRESTAMO\n";
            cout<<"NUMERO DEL PRESTAMO: "<< prest->getNumPrestamo() <<endl;
            cout<<"CLIENTE: "<< prest->getCliente()->getNombre() <<" "<< prest->getCliente()->getApellido() <<endl;
            cout<<"MONTO APROBADO DEL PRESTAMO: "<< prest->getMontoAprobado() <<endl;

            if(prest->getContadorPagos()==0) {
                cout<<"NO SE HA REALIZADO NINGUN PAGO\n";
            } else {
                cout<<"LISTA DE PAGOS REALIZADOS:\n";
                cout<<"FECHA\tMONTO\n";
                Pago **lstP=prest->getlstPago();
                for(int i=0; i<prest->getContadorPagos();i++) {
                    Pago *pg=lstP[i];
                    pg->getFechaPago()->mostrarFecha();
                    cout<<"\t"<<pg->getMontoPago()<<"\n";
                }
            }
        } else {
            cout<<"NO SE ENCONTRO EL PRESTAMO\n";
        }
    }
}

int main() {
    int opc;
    CLIENTE *lstCli[Var];
    Prestamo *lstPrestamo[Var];
    int contCli=0, contPr=0;
    do {
        system("cls");
        opc=menu();
        switch(opc) {
            case 1:
                if (contCli < Var) {
                    lstCli[contCli] = agregarCliente();
                    contCli++;
                    cout << "EL CLIENTE SE AGREGO EXITOSAMENTE\n";
                } else {
                    cout << "LA LISTA DE CLIENTES ESTA LLENA\n";
                }
                break;
            case 2:
                if (contPr < Var) {
                    lstPrestamo[contPr] = agregarPrestamo(lstCli,contCli);
                    contPr++;
                    cout << "EL PRESTAMO SE AGREGO CON EXITO\n";
                } else {
                    cout << "LA LISTA DE PRESTAMOS ESTA LLENA\n";
                }
                break;
            case 3:
                realizarPago(lstPrestamo, contPr);
                break;
            case 4:
                mostrarCliente(lstCli,contCli);
                break;
            case 5:
                mostrarPrestamo(lstPrestamo,contPr);
                break;
            case 6:
                mostrarDetallesPrestamo(lstPrestamo, contPr);
                break;
            case 7:
                cout << "USTED ESTA SALIENDO DEL PROGRAMA...\n";
                break;
            default:
                cout << "ERROR"<<endl;
                break;
        }
        system("pause");
    } while(opc!=7);
    return 0;
}
